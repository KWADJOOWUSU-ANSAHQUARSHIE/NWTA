package com.example.hospital;

public interface initializable {
}
